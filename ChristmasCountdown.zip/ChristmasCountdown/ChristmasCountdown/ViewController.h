//
//  ViewController.h
//  ChristmasCountdown
//
//  Created by Tan Zhegui on 12/9/16.
//  Copyright © 2016 Tan Zhegui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController

@property (weak, nonatomic) IBOutlet UILabel *lblTime;
- (IBAction)unlockScreen:(id)sender;
@property (weak, nonatomic) IBOutlet UIImageView *imgFirstDay;
@property (weak, nonatomic) IBOutlet UIImageView *imgSecondDay;

@end

