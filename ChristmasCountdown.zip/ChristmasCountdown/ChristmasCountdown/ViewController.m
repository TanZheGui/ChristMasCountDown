//
//  ViewController.m
//  ChristmasCountdown
//
//  Created by Tan Zhegui on 12/9/16.
//  Copyright © 2016 Tan Zhegui. All rights reserved.
//

#import "ViewController.h"
#define degreesToRadians(degrees) (3.141592 * degrees / 180.0)

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [NSTimer scheduledTimerWithTimeInterval:1.0
                                     target:self
                                   selector:@selector(timeNotify)
                                   userInfo:nil
                                    repeats:YES];
    [self calculateDaysOfXMas];
    self.imgSecondDay.transform = CGAffineTransformMakeRotation(degreesToRadians(5));
    self.imgFirstDay.transform = CGAffineTransformMakeRotation(degreesToRadians(8));
}

- (void) timeNotify
{
    NSDate *currentTime = [NSDate date];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"hh:mm"];
    NSString *resultString = [dateFormatter stringFromDate: currentTime];
    _lblTime.text = resultString;
}

-(void) calculateDaysOfXMas{
    
    NSCalendar *calendar = [NSCalendar currentCalendar];
    NSDate *startDate = [NSDate date];
    
    //gather date components from date
    NSDateComponents *dateComponents = [calendar components:(NSCalendarUnitDay | NSCalendarUnitMonth | NSCalendarUnitYear) fromDate:[NSDate date]];
    
    //set date components
    [dateComponents setDay:25];
    [dateComponents setMonth:12];
    
    //save date relative from date
    NSDate *endDate = [calendar dateFromComponents:dateComponents];
    
    NSCalendar *gregorianCalendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSCalendarIdentifierGregorian];
    NSDateComponents *components = [gregorianCalendar components:NSCalendarUnitDay
                                                        fromDate:startDate
                                                          toDate:endDate
                                                         options:0];
    NSInteger days = [components day];
    int firstNum = 0, secondNum = 0;
    if(days <= 99){
        firstNum = days / 10;
        secondNum = days % 10;
    }
    [_imgFirstDay setImage:[UIImage imageNamed:[NSString stringWithFormat:@"number_%d.png", firstNum]]];
    [_imgSecondDay setImage:[UIImage imageNamed:[NSString stringWithFormat:@"number_%d.png", secondNum]]];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)unlockScreen:(id)sender {
    exit(0);
}
@end
