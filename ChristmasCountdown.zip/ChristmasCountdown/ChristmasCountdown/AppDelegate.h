//
//  AppDelegate.h
//  ChristmasCountdown
//
//  Created by Tan Zhegui on 12/9/16.
//  Copyright © 2016 Tan Zhegui. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

